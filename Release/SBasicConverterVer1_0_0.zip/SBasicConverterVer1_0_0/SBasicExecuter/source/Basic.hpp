#ifndef BASIC_HPP
#define BASIC_HPP

// Program line define
#define L00010_01 0
#define L00010_02 1
#define L00010_03 2
#define L00010_04 3
#define L00010_05 4
#define L00020_01 5
#define L00030_01 6
#define L00040_01 7
#define L00050_01 8
// Data line define

#endif
