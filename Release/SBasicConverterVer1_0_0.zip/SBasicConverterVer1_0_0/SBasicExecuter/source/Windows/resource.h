//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// WinMain.rc �Ŏg�p
//
#define IDI_ICON                        100
#define IDM_EXIT                        101
#define IDC_WINMAIN                     102
#define ID_WINDOWSIZEx1                 32771
#define ID_WINDOWSIZEx2                 32772
#define ID_WINDOWSIZEx3                 32773
#define ID_SPEED_MIN                    32774
#define ID_SPEEDx1                      32775
#define ID_SPEEDx2                      32776
#define ID_SPEEDx5                      32777
#define ID_SPEEDx20                     32778
#define ID_SPEEDx100                    32779
#define ID_SPEEDx200                    32780
#define ID_SPEED_MAX                    32781
#define ID_SETTING_SCREENCOLOR          32782
#define ID_DISPLAYCOLOR_COLOR           32783
#define ID_DISPLAYCOLOR_GREEN           32784
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
