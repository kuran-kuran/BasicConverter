#ifndef JIKENPATCH_HPP
#define JIKENPATCH_HPP

void JikenPatch(void);

#endif
