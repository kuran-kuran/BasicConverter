#ifndef WINMAIN_HPP
#define WINMAIN_HPP

#include <Windows.h>

unsigned int* GetFrameBuffer(void);
HWND GetWindowHandle(void);

#endif
