#define IDI_ICON        100
#define IDM_EXIT        101
#define IDC_WINMAIN     102
#define ID_WINDOWSIZEx1 32771
#define ID_WINDOWSIZEx2 32772
#define ID_WINDOWSIZEx3 32773
#define ID_SPEED_MIN    32774
#define ID_SPEEDx1      32775
#define ID_SPEEDx2      32776
#define ID_SPEEDx5      32777
#define ID_SPEEDx20     32778
#define ID_SPEEDx100    32779
#define ID_SPEEDx200    32780
#define ID_SPEED_MAX    32781
#define IDC_STATIC      -1

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC                 130
#define _APS_NEXT_RESOURCE_VALUE    129
#define _APS_NEXT_COMMAND_VALUE     32782
#define _APS_NEXT_CONTROL_VALUE     1000
#define _APS_NEXT_SYMED_VALUE       103
#endif
#endif
