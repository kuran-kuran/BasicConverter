#define FPS 60
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 200
#define DISPLAY_WIDTH 640
#define DISPLAY_HEIGHT 400
#define FONT_WIDTH 8
#define FONT_HEIGHT 8
#define WINDOW_TITLE L"Basic Executer"
