#ifndef SETTING_HPP
#define SETTING_HPP

struct Setting
{
	int screenWidth;
	int screenHeight;
	int textScreenWidth;
	int textScreenHeight;
};

#endif
