#ifndef DEPENDENT_HPP
#define DEPENDENT_HPP

#if defined(_WIN32)
#include "Windows/KeyBoard.hpp"
#include "Windows/SoundStream.hpp"
#endif

#endif
