#ifndef FORMAT_HPP
#define FORMAT_HPP

#include "String.hpp"

namespace dms
{
	dms::String Format(const char* format, ...);
};

#endif
